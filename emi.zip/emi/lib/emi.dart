import 'package:firstappexample/widgets/button.dart';
import 'package:firstappexample/widgets/output.dart';
import 'package:firstappexample/widgets/textbox.dart';
import 'package:flutter/material.dart';
//EMI = P × r × (1 + r)n/((1 + r)n - 1)

class EMI extends StatefulWidget {
  @override
  _EMIState createState() => _EMIState();
}

class _EMIState extends State<EMI> {
  double principal = 0.0;
  double interest = 0.0;
  int months = 0;
  double emi = 0.0;
  _getPrincipalAmount(String amount) {
    principal = double.parse(amount);
  }

  _getInterestAmount(String interest) {
    this.interest = double.parse(interest);
  }

  _getMonths(String months) {
    this.months = int.parse(months);
  }

  _compute() {
    double monthInterest = principal * (interest / 100); //10/100 = 0.10
    emi = (principal + monthInterest) / months;
    // double i = (interest / (12 * 100));
    // double result = math.pow((((1 + i))), months);
    // double secondResult = math.pow((1 + i), (months - 1));
    // emi = (principal * i * result) / secondResult;
    print("EMI is $emi");
    setState(() {});
  }

  _clearAll() {}

  @override
  Widget build(BuildContext context) {
    print("Build Called");
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        backgroundColor: Colors.orangeAccent,
        title: Text('EMI CALC'),
        leading: IconButton(
            icon: Icon(
          Icons.menu,
          color: Colors.white,
        )),
      ),
      body: Container(
        child: Column(
          children: [
            Container(
              color: Colors.white,
              child: Column(
                children: [
                  TextBox('Loan Amount', 'Enter the Loan Amount Here',
                      _getPrincipalAmount),
                  TextBox('Interest %', 'Enter the Loan Interest',
                      _getInterestAmount),
                  TextBox('Period %', 'In Months', _getMonths,
                      icon: Icon(Icons.calendar_today)),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      CustomButton('Calculate', _compute),
                      CustomButton('Clear All', _clearAll)
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  )
                ],
              ),
            ),
            Output('Monthly EMI ', emi.toStringAsFixed(2)),
            Output('Periods (Monthly) ', months.toString()),
            Output('Total Interest ', (emi * months).toStringAsFixed(2)),
            Output('Total Payment ',
                ((principal) + (emi * months)).toStringAsFixed(2))
          ],
        ),
      ),
    );
  }
}
