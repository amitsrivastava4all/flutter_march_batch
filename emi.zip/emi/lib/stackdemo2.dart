import 'package:flutter/material.dart';

class StackDemo2 extends StatelessWidget {
  _getContainer(
      {Color color = Colors.redAccent,
      double width = 100.0,
      double height = 100.0}) {
    return Container(
      color: color,
      width: width,
      height: height,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SafeArea(
            child: Container(
              color: Colors.lightGreenAccent,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  /*Banner(
                  message: 'Top Start',
                  location: BannerLocation.topStart,
                  color: Colors.redAccent,
                ),
                Banner(
                    message: 'BottomEnd',
                    location: BannerLocation.bottomEnd,
                    color: Colors.purpleAccent),
                Banner(
                    message: 'Top Right',
                    location: BannerLocation.topEnd,
                    color: Colors.blue),
                Banner(
                  message: 'I am on Bottom Left',
                  location: BannerLocation.bottomStart,
                )*/
                  Positioned(
                    top: constraints.maxHeight / 3,
                    left: constraints.maxWidth / 2,
                    child: _getContainer(
                        color: Colors.blue, width: 200, height: 200),
                  ),
                  Positioned(
                    top: constraints.maxHeight / 4,
                    left: constraints.maxWidth / 4,
                    child: _getContainer(),
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
