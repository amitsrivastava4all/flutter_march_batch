import 'package:flutter/material.dart';

class TextBox extends StatelessWidget {
  String helperText;
  String label;
  Icon icon;
  Function function;
  TextBox(this.helperText, this.label, this.function, {this.icon}) {}
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      child: TextField(
       onChanged: (String str){
         this.function(str);
       },
        decoration: InputDecoration(
            prefixIcon: this.icon ?? Icon(Icons.attach_money),
            //hintText: 'Loan',
            helperText: helperText,
            labelStyle: TextStyle(
                fontWeight: FontWeight.bold, color: Colors.purpleAccent),
            labelText: label,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10.0))),
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
