import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  String label;
  Color color;
  Function function;
  CustomButton(this.label, this.function, {this.color = Colors.orangeAccent}) {}
  @override
  Widget build(BuildContext context) {
    return Container(
      child: RaisedButton(
        elevation: 5,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        padding: EdgeInsets.all(10),
        color: color,
        onPressed: () {
          this.function();
        },
        child: Text(
          label,
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
