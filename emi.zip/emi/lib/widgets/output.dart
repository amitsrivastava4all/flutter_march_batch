import 'package:flutter/material.dart';

class Output extends StatelessWidget {
  String outputKey;
  String value;
  Output(this.outputKey, this.value) {}
  _getStyle() {
    return TextStyle(fontSize: 20);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      //margin: EdgeInsets.symmetric(horizontal: 10),
      margin: EdgeInsets.all(10),
      child: Card(
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.all(10),
                child: Text(
                  outputKey,
                  style: _getStyle(),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(10),
                child: Text(
                  value,
                  style: _getStyle(),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
