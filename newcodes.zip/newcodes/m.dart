class A {
  int x = 100;
}

void main() {
  // ?? vs ??=  vs ? vs  ..? vs ?: vs ?.
  //
  String? name;
  print(name ?? 'Ram');
  name ??= 'Amit';
  print(name);
  //A? obj;
  A obj = new A();
  print(obj?.x);
  List<int>? list2;
  List<int> list3 = [...?list2];
  print(list3);
  String result = name == null ? 'Null Value' : 'It has Value';
  print(result);
}
