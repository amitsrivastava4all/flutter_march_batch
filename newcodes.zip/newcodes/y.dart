int add([int? x, int? y]) {
  return (x ?? 0) + (y ?? 0);
}

class Customer {
  // int? id;
  // String? name;
  // double? balance;
  late int id;
  late String name;
  late double balance;
  // default constructor
  Customer() {
    // nothing
    id = 1001;
    name = 'Ram';
    balance = 99999;
  }
  Customer.takeInput(int id, String name, double balance) {
    this.id = id;
    this.name = name;
    this.balance = balance;
  }
}

void main() {
  //Customer customer = new Customer();
  Customer customer = Customer.takeInput(1001, 'Abcd');
  add();
}
