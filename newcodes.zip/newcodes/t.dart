void main() {
  int? a;
  List<int?>? list = null;
  list = [a, a];
  Map<String, int?>? map = {"a": null};

  int? x;
  int y = x!;
  print(y);
}
