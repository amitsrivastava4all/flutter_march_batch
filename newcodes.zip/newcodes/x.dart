void main() {
  //String name ; // Invalid in null -safe dart
  String? name;
  print(name);
}
