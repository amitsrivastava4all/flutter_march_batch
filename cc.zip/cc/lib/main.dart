import 'package:flutter/material.dart';
import './screens/splashscreen.dart';

void main() {
  runApp(MaterialApp(
    title: 'News App',
    home: SplashScreen(),
  ));
}
