import 'package:flutter/material.dart';
class NewsDrawer extends StatelessWidget {
  const NewsDrawer({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      elevation: 5,
      child: ListView(
        children: [
          UserAccountsDrawerHeader(accountName: Text('Brain Mentors'),
              accountEmail: Text('brainmentorspvtltd@gmail.com'),
              currentAccountPicture: CircleAvatar(
                //maxRadius: 100,
                //radius: 100,
                backgroundImage: NetworkImage('https://img.icons8.com/bubbles/2x/user-male.png'),
                backgroundColor: Colors.deepPurpleAccent,
                //child: Text('BM',style: TextStyle(fontSize: 40),),
              ),
          ),
          InkWell(
            highlightColor: Colors.amberAccent,
            onTap: (){

            },
            child: ListTile(title: Text('Latest News'),
              trailing: Icon(Icons.chrome_reader_mode,color: Colors.deepOrange,),),
          )
        ],
      ),
    );
  }
}
