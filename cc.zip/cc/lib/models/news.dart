class News{
  String title;
  String url;
  String desc;
  String date;
  News(this.title , this.url, this.desc , this.date){}




}
