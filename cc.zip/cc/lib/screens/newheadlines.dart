import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:fluttercodes/models/news.dart';
import 'package:fluttercodes/widgets/newsdrawer.dart';
import '../utils/server.dart';
import 'detailnews.dart';

class NewsHeadlines extends StatefulWidget {
  @override
  _NewsHeadlinesState createState() => _NewsHeadlinesState();
}

class _NewsHeadlinesState extends State<NewsHeadlines> {

  List<News> news = [];
  storeNewsData() async{
    Response<dynamic> response = await Server.getHeadLines();
    //print("::::: response Data is ${response.data} ");
    Map<String, dynamic> map = response.data;

    List<dynamic> list = map['articles'];
    print("!!!!! Articles is $list");
    news = list.map((dynamic currentNews)=>new News(currentNews['title'],currentNews['urlToImage'],
        currentNews['description'],
        currentNews['publishedAt'])).toList();

  }

  showDetailNews(String title){
    int index = news.indexWhere((News currentNews) {
      print("News is ${currentNews}");
      print("Type is ${currentNews.runtimeType}");
      String currentTitle = currentNews.title;
      return currentTitle.contains(title);
    });
    if(index!=-1){
      Navigator.push(context, MaterialPageRoute(builder: (ctx)=>DetailNews(news[index])));
    }
  }




  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    storeNewsData();
    print("Server Call");
    // Future<Response> future = Server.getHeadLines();
    // future
    //     .then((response) => print("Res Data ${response.data['articles']}"))
    //     .catchError((err) => print(err));
  }

  @override
  Widget build(BuildContext context) {
    print("Build Call");
    return Scaffold(
      appBar: AppBar(
        title: Text('HeadLines'),
      ),
      drawer: NewsDrawer(),
      body: Container(
        child: FutureBuilder(
          future: Server.getHeadLines(),
          builder: (BuildContext context,
              AsyncSnapshot<Response<dynamic>> snapShot) {
            if (snapShot.hasData == true &&
                snapShot.connectionState == ConnectionState.done) {
              print("Snap Shot State is  ${snapShot.connectionState}");
              //snapShot.data.he
              print(snapShot.data.data['articles']); //
              dynamic articles = snapShot.data.data['articles'];
              print("Articles " + articles.length.toString());
              // return Text('News');
              return ListView.builder(
                itemCount: articles.length,
                itemBuilder: (BuildContext btx, int index) {
                  return Card(
                    elevation: 5,

                    margin: EdgeInsets.all(5),
                    child: ListTile(
                      onTap: (){
                        print("Title is ${articles[index]['title']}");
                        showDetailNews(articles[index]['title']);
                      },

                      subtitle: Text(articles[index]['title']),
                      title: articles[index]['urlToImage'] == null
                          ? Text('No Image')
                          : Container(
                              //margin: EdgeInsets.all(10),
                              //padding: EdgeInsets.all(5),
                              child: Image.network(
                                articles[index]['urlToImage'],
                                fit: BoxFit.fill,
                              ),
                            ),
                    ),
                  );
                },
              );
            } else if (snapShot.hasError) {
              return Center(
                child: Text(
                  'Some Error Occur ',
                  style: TextStyle(fontSize: 40),
                ),
              );
            } else {
              return Center(
                child: Text(
                  'Loading....',
                  style: TextStyle(fontSize: 40),
                ),
              );
            }
          },
        ),
      ),
    );
  }
}
