
import 'package:flutter/material.dart';
import 'package:fluttercodes/models/news.dart';
class DetailNews extends StatelessWidget {
  News newsObject;
  DetailNews(this.newsObject,{Key key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(newsObject.title),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Text(this.newsObject.title, style: TextStyle(fontSize: 22),),
            Image.network(this.newsObject.url),
            Text(this.newsObject.desc, style: TextStyle(fontSize: 20, color: Colors.blueAccent),)
          ],
        ),
      ),
    );
  }
}
