import 'package:flutter/material.dart';

class Zomato extends StatelessWidget {
  _rating({double ratingValue = 4.0}) {
    return Container(
      padding: EdgeInsets.all(15),
      decoration: BoxDecoration(
          color: Colors.green, borderRadius: BorderRadius.circular(15.0)),
      child: Text(
        ratingValue.toString(),
        style: TextStyle(fontSize: 20, color: Colors.white),
      ),
    );
  }

  _leftSection() {
    return Expanded(
        child: Column(
      children: [
        Expanded(
          child: Image.asset(
            'images/food.jpg',
            fit: BoxFit.cover,
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Text(
              'The Bold Cafe',
              style: TextStyle(fontSize: 20),
            ),
            _rating()
          ],
        )
      ],
    ));
  }

  _rightSection() {
    return Expanded(
        child: Column(
      children: [
        Text('The Bold Cafe'),
        Text('New York'),
        Divider(
          height: 2,
          thickness: 2,
          color: Colors.black,
        )
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Zomato App'),
      ),
      body: Row(
        children: [_leftSection(), _rightSection()],
      ),
    );
  }
}
