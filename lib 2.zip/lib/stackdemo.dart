import 'package:flutter/material.dart';

class StackDemo extends StatelessWidget {
  _getContainer(
      {Color color = Colors.redAccent,
      double width = 100.0,
      double height = 100.0}) {
    return Container(
      color: color,
      width: width,
      height: height,
    );
  }

  // Non Positioned
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('This is Stack'),
      ),
      body: Container(
        width: 400,
        height: 600,
        color: Colors.greenAccent,
        child: Stack(
          fit: StackFit.loose, // expand as child size
          //fit: StackFit.expand, // expand (child widget as expanded as)
          children: [
            //Container(color: Colors.yellowAccent),
            _getContainer(color: Colors.blue, width: 300, height: 300),
            _getContainer(color: Colors.green, width: 200, height: 200),
            _getContainer(color: Colors.orange, width: 100, height: 100)
          ],
        ),
      ),
    );
  }
}
