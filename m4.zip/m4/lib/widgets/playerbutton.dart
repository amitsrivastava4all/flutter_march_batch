import 'package:flutter/material.dart';
class PlayerButton extends StatelessWidget {
  IconData _icon;
  double _size;
  Function _fn;
  Color color;

  PlayerButton( this._icon, this._size , this._fn,  {Key key, this.color=Colors.green}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: SizedBox(
        height: _size,
        //margin: EdgeInsets.all(5),
        child: IconButton(icon: Icon(_icon,size: _size,
          color: color,), onPressed: (){
          _fn();
        }),
      ),
    );
  }
}
