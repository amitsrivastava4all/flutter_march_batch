import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:musicapp/models/song.dart';
import 'package:musicapp/widgets/playerbutton.dart';
class Player extends StatefulWidget {
  Song song;
   Player(this.song, {Key key}) : super(key: key);

  @override
  _PlayerState createState() => _PlayerState();
}

class _PlayerState extends State<Player> {
  AudioPlayer audioPlayer;
  bool isPlaying = false;
  _playSong(){
    setState(() {
      isPlaying = !isPlaying;
      if(isPlaying) {
        _playSongOnPlayer(widget.song.audioURL);
      }
      else{
        _pauseSong();
      }
    });
  }

  _pauseSong() async{
    int response = await audioPlayer.pause();
    if(response == 1){
      setState(() {
        isPlaying = false;
      });
    }
    else{
      isPlaying = true;
      print("Error During Pause ");
    }
    setState(() {

    });
  }

  _playSongOnPlayer(String path) async{
    int response = await audioPlayer.play(path);
    if(response == 1){
      setState(() {
        isPlaying = true;
      });
    }
    else{
      isPlaying = false;
      print("Error During Play ");
    }
    setState(() {

    });
  }


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    audioPlayer = new AudioPlayer();
  }


  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      body: SafeArea(
        child: Column(

          children: [
            Container(
              alignment: Alignment.center,

              color: Colors.deepPurpleAccent,
              height: size.height * 0.40,
              width: double.infinity,
              child: Stack(
                children: [
                  Container(
                    height: size.height * 0.30,
                    width: size.height * 0.30,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white, width: 5),
                      shape: BoxShape.circle,
                      image: DecorationImage(
                        fit: BoxFit.fill,
                        image: NetworkImage(widget.song.photo)
                      )
                    ),
                  )
                ],
              ),
            ),
          
          Padding(
            padding: EdgeInsets.all(10),
              child: Text(widget.song.name,style:
              TextStyle(fontSize: 20, fontWeight: FontWeight.bold),)),
            Text(widget.song.artistName,style: TextStyle(fontSize: 20),),
            Row(

              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.center,

              crossAxisAlignment: CrossAxisAlignment.center,
              //verticalDirection: VerticalDirection.down,
              children: [
                PlayerButton(Icons.skip_previous, 40, ()=>{}, color: Colors.blue),
                PlayerButton(!isPlaying?Icons.play_circle_fill_outlined:Icons.pause_circle_filled_sharp, 100, _playSong),
                PlayerButton(Icons.stop, 40, ()=>{}, color: Colors.redAccent,),
                PlayerButton(Icons.skip_next, 40, ()=>{}, color: Colors.blue)


            ],)

          ],
        ),
      ),
    );
  }
}
