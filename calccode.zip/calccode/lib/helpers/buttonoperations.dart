import 'package:calcdemo/widgets/button.dart';
import 'package:flutter/material.dart';

class ButtonOperations {
  Function _fn;
  ButtonOperations(this._fn) {}
  List<CalcButton> firstRowData() {
    List<CalcButton> list = [];
    list.add(CalcButton("C", _fn, color: Colors.black12));
    list.add(CalcButton("+/-", _fn, color: Colors.black12));
    list.add(CalcButton("%", _fn, color: Colors.black12));
    list.add(CalcButton("/", _fn, color: Colors.orangeAccent));
    return list;
  }

  List<CalcButton> secondRowData() {
    List<CalcButton> list = [];
    list.add(CalcButton("7", _fn));
    list.add(CalcButton("8", _fn));
    list.add(CalcButton("9", _fn));
    list.add(
      CalcButton("X", _fn, color: Colors.orangeAccent),
    );
    return list;
  }

  List<CalcButton> thirdRowData() {
    List<CalcButton> list = [];
    list.add(CalcButton("4", _fn));
    list.add(CalcButton("5", _fn));
    list.add(CalcButton("6", _fn));
    list.add(CalcButton("-", _fn));
    return list;
  }

  List<CalcButton> fourthRowData() {
    List<CalcButton> list = [];
    list.add(CalcButton("1", _fn));
    list.add(CalcButton("2", _fn));
    list.add(CalcButton("3", _fn));
    list.add(CalcButton("+", _fn));
    return list;
  }

  List<CalcButton> fifthRowData() {
    List<CalcButton> list = [];
    list.add(CalcButton("0", _fn));
    list.add(CalcButton(".", _fn));
    list.add(CalcButton("=", _fn));

    return list;
  }
}
