import 'package:flutter/material.dart';

class ButtonModel {
  String name;
  Colors color;
  Function fn;
  ButtonModel(this.name, this.color, this.fn);
}
