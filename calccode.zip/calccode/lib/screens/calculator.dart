import 'package:calcdemo/helpers/buttonoperations.dart';
import 'package:calcdemo/widgets/calcrow.dart';
import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';

class Calculator extends StatefulWidget {
  @override
  _CalculatorState createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  // one time call
  @override
  initState() {
    super.initState();
    _buttonOperations = new ButtonOperations(setText);
  }

  String currentValue = "0";
  _getText() {
    Size deviceSize = MediaQuery.of(context).size;

    return Row(
      children: [
        Expanded(
            child: Container(
          padding: EdgeInsets.only(top: 20),
          //color: Colors.purple,
          height: deviceSize.height / 8,
          child: Text(
            currentValue,
            style: TextStyle(
              fontSize: 40,
              color: Colors.white,
            ),
            textDirection: TextDirection.rtl,
          ),
        ))
      ],
    );
  }

  computeResult() {
    ContextModel cm = new ContextModel();
    Parser p = new Parser();
    Expression exp = p.parse(currentValue);
    dynamic eval = exp.evaluate(EvaluationType.REAL, cm);
    eval = eval.toInt();
    currentValue = eval.toString();
    setState(() {});
  }

  setText(String text) {
    if (text == "=") {
      computeResult();
      return;
    }
    if (currentValue == "0") {
      currentValue = text;
    } else {
      currentValue += text;
    }
    print(currentValue);
    setState(() {});
  }

  ButtonOperations _buttonOperations;

  @override
  Widget build(BuildContext context) {
    print("Calc ...... ");
    print(_buttonOperations);
    return Scaffold(
      body: SafeArea(
        child: Container(
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.only(right: 20),
                color: Colors.black12,
                child: _getText(),
              ),
              CalcRow(4, _buttonOperations.firstRowData),
              CalcRow(4, _buttonOperations.secondRowData),
              CalcRow(4, _buttonOperations.thirdRowData),
              CalcRow(4, _buttonOperations.fourthRowData),
              CalcRow(3, _buttonOperations.fifthRowData)
            ],
          ),
        ),
      ),
    );
  }
}
