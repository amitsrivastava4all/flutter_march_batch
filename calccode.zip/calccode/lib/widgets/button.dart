import 'package:flutter/material.dart';

class CalcButton extends StatelessWidget {
  String _text;
  Function _fn;
  Color color;
  CalcButton(this._text, this._fn, {this.color = Colors.grey});
  @override
  Widget build(BuildContext context) {
    return Expanded(
        child: GestureDetector(
      onTap: () {
        _fn(_text);
      },
      child: Container(
        decoration: BoxDecoration(
            color: color, border: Border.all(color: Colors.black)),
        child: Center(
          child: Text(
            _text,
            style: TextStyle(fontSize: 30),
          ),
        ),
      ),
    ));
    //   child: FlatButton(
    //       padding: EdgeInsets.all(10),
    //       color: color,
    //       onPressed: () {
    //         _fn();
    //       },
    //       child: Text(
    //         _text,
    //         style: TextStyle(fontSize: 30),
    //       )),
    // );
  }
}
