import 'package:flutter/material.dart';

import 'button.dart';

class CalcRow extends StatelessWidget {
  int _noOfElements;
  Function _fn;

  CalcRow(this._noOfElements, this._fn) {}

  _createChildren() {
    List<Widget> list = [];
    List<CalcButton> buttons = _fn();
    for (int i = 0; i < _noOfElements; i++) {
      list.add(buttons[i]);
    }
    // list.add(CalcButton("C", () {}));
    // list.add(CalcButton("+/-", () {}));
    // list.add(CalcButton("%", () {}));
    // list.add(CalcButton("/", () {}));
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 1,
      child: Container(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: _createChildren(),
        ),
      ),
    );
  }
}
