import 'package:calcdemo/screens/calculator.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    title: "Calc App",
    home: Calculator(),
    theme: ThemeData.dark(),
  ));
}
