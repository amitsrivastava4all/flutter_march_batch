import 'package:flutter/material.dart';

import 'common/config/config.dart';
void main() {
  FlavorConfig(flavor: Flavor.DEV,
      color: Colors.redAccent,
      values: FlavorValues(baseUrl: "http://10.1.10.90:1234"));
    runApp(
      MaterialApp()
    );
}