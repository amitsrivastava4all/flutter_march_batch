import 'package:dio/dio.dart';
import 'package:test_engine/common/config/config.dart';

/// Here We call the BackEnd API'S
/// ApiClient is Just a Wrapper on Top of DIO Client
class ApiClient{
  static var _dio ;
  static BaseOptions _options;
  _ApiClient(){
    init();
  }
   static void init() {
// Set default configs
     _options = BaseOptions(
      // baseUrl: 'https://www.xx.com/api',
       baseUrl: FlavorConfig.instance.values.baseUrl,
       connectTimeout: 5000,
       receiveTimeout: 3000,
     );
     _dio = new Dio(_options);
   }

   static get(String url) async{
   Response response = await _dio.get(url);
   return response;
   }
  static post(String url, Map<String, dynamic> data) async{
    Response response = await _dio.post(url,data: data);
    return response;
  }





}