import 'package:flutter/material.dart';

import 'common/config/config.dart';
void main() {
  FlavorConfig(flavor: Flavor.QA,
      color: Colors.redAccent,
      values: FlavorValues(baseUrl: "http://10.1.10.190:1234"));
  runApp(
      MaterialApp()
  );
}