class ApiService{
  /// Call Api Client
  /// Success - result , Fail - Exception
}