// How to DO
import 'package:test_engine/login/domain/entities/user.dart';
import 'package:test_engine/login/domain/interfaces/user_interface.dart';

/// Call API Client get the response and convert it and give result to presentation
/// How to do
class UserRepository implements UserInterface{
  @override
  login(User userObject) {
    // TODO: implement login
    throw UnimplementedError();
  }

  @override
  register() {
    // TODO: implement register
    throw UnimplementedError();
  }

  @override
  removeUser() {
    // TODO: implement removeUser
    throw UnimplementedError();
  }

  @override
  updatePassword() {
    // TODO: implement updatePassword
    throw UnimplementedError();
  }



}
