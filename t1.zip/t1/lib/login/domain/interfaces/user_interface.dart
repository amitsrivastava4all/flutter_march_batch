import 'package:test_engine/login/domain/entities/user.dart';
/// What to Do
/// User Operations - CRUD
class UserInterface{

  register(){

  }
  login(User userObject){

  }
  updatePassword(){

  }
  removeUser(){

  }

}
