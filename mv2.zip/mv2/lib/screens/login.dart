
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:musicapp/screens/singers.dart';
import 'package:musicapp/utils/constants.dart';
import 'package:musicapp/widgets/custombutton.dart';
class Login extends StatefulWidget {
  const Login({Key key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = new GoogleSignIn();
  loginWithGmail() async{
    print("Login With Gmail ");
    GoogleSignInAccount googleSignInAccount= await _googleSignIn.signIn();
    GoogleSignInAuthentication googleSignInAuthentication = await googleSignInAccount.authentication;
    AuthCredential authCredential = GoogleAuthProvider.credential(accessToken: googleSignInAuthentication.accessToken, idToken: googleSignInAuthentication.idToken );
    UserCredential userCredential = await _auth.signInWithCredential(authCredential);
    User user = userCredential.user;
    print(user.displayName);
    print(user.email);
    print(user.photoURL);
    print(user.phoneNumber);
    Navigator.of(context).push(MaterialPageRoute(builder: (ctx)=>SingerScreen(user)));
  }
  loginWithFB(){
    print("Login With FB ");
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(
              child: Image.network(Constants.LOGIN_IMG_URL,fit: BoxFit.fill),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomButton(Constants.GOOGLE_URL, loginWithGmail),
                CustomButton(Constants.FB_URL, loginWithFB)
              ],
            )
          ],
        ),
      ),
    );
  }
}
