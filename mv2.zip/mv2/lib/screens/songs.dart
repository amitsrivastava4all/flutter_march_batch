import 'package:flutter/material.dart';
import 'package:musicapp/models/song.dart';
import 'package:musicapp/respositories/server.dart';
class Songs extends StatefulWidget {
  String singerName;
   Songs( this.singerName, {Key key}) : super(key: key);

  @override
  _SongsState createState() => _SongsState();
}

class _SongsState extends State<Songs> {

  _printSong(Song song){
    return Card(
      child: ListTile(
        leading: Image.network(song.photo),
        title: Text(song.name),
        subtitle: Text(song.artistName),
        trailing: IconButton(icon: Icon(Icons.play_circle_fill), color: Colors.redAccent,onPressed: (){},),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: FutureBuilder(
          future: Server.getSongBySinger(widget.singerName),
          builder: (BuildContext context, AsyncSnapshot<List<Song>> snapShot){
            if(snapShot.hasError){
              return Text('Error in Song Fetching...');
            }
            if(!snapShot.hasData){
              return Center(child: CircularProgressIndicator(),);
            }
            return ListView.builder(itemCount: snapShot.data.length,
            itemBuilder: (BuildContext parent , int index){
              return _printSong(snapShot.data[index]);
            },
            );
          },
        ),
      ),
    );
  }
}
