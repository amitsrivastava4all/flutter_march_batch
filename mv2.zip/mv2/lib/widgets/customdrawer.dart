import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
class CustomerDrawer extends StatelessWidget {
  User user;
  CustomerDrawer(this.user, {Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      elevation: 5,
      child: ListView(
        children: [
          UserAccountsDrawerHeader(accountName: Text(user.displayName),
              accountEmail: Text(user.email),
              currentAccountPicture: Image.network(user.photoURL),
              decoration: BoxDecoration(
                color: Colors.deepPurple,
                boxShadow: [BoxShadow(color:Colors.redAccent, blurRadius: 5)]
              ),

          ),
          ListTile(
            leading: Icon(Icons.library_music),
            title:Text('My PlayList')
          ),
          Divider(
            height: 1,
            thickness: 2,
            color: Colors.black,
          ),
          ListTile(
              leading: Icon(Icons.library_music),
              title:Text('Logout')
          )
        ],
      ),
      
    );
  }
}
