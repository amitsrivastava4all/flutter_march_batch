
import 'package:flutter/material.dart';
class CustomButton extends StatelessWidget {
  String url;
  Function _fn;
  CustomButton( this.url, this._fn , {Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
          this._fn();
      },
      child: Container(
        height: 100,
        margin: EdgeInsets.all(20),
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
           color: Colors.amber,
           border: Border.all(color: Colors.black, width: 2.0,style: BorderStyle.solid),
          borderRadius: BorderRadius.circular(30)
        ),
        child: Row(
          children: [
              Expanded(child: Image.asset(this.url), flex: 1,),
              Expanded(child: Text('Login', style: TextStyle(fontSize: 30, color: Colors.blue, fontWeight: FontWeight.bold),) , flex: 1,)
          ],
        ),
      ),
    );
  }
}
