import 'package:dio/dio.dart';
import 'package:musicapp/models/singer.dart';
import 'package:musicapp/models/song.dart';
import 'package:musicapp/utils/constants.dart';
import 'dart:convert' as jsonconvert;
class Server{

  _Server(){}

  static final Dio _dio = Dio();
  static Future<List<Singer>> getSingers() async{
    Response response = await _dio.get(Constants.SINGER_URL);
    //print(response.data.runtimeType);
    dynamic map = jsonconvert.jsonDecode(response.data);
    print(map);
    print(map.runtimeType);
    List<dynamic> list = map['singers'];
    List<Singer> singerList = list.map((singer) => new Singer(singer['name'], singer['photo'])).toList();
    return singerList;
  }

  static Future<List<Song>> getSongBySinger(String singerName) async{
    Response response = await _dio.get(Constants.getSongURL(singerName));
    //print(response.data.runtimeType);
    dynamic map = jsonconvert.jsonDecode(response.data);
    print(map);
    print(map.runtimeType);
    List<dynamic> list = map['results'];
    List<Song> songList = list.map((song) => new Song(song['trackName'], song['artworkUrl100'], song['artistName'], song['previewUrl'])).toList();
    return songList;
  }

}
