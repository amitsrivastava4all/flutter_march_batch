
import 'dart:io';

import 'package:flutter_audio_query/flutter_audio_query.dart';
import 'package:musicapp/utils/toast.dart';
import 'package:permission_handler/permission_handler.dart';



class LocalSong{
  static final FlutterAudioQuery audioQuery = FlutterAudioQuery();
  static List<String> songs = [];
  LocalSong(){
    checkPermission();
  }
  checkPermission() async{
    if(await Permission.storage.request().isGranted){
      songs = loadSongs();
    }
    else if(await Permission.storage.isPermanentlyDenied){
      showToast('No Permission for SD Card');
    }
  }

  static loadSongs2() async{
    /// getting all songs available on device storage
    print("Load Song2 Called...");
    List<SongInfo> songs = await audioQuery.getSongs();
    print("LOAD SONG2 are $songs");
    songs.forEach( (song){
      print('Song is $song');
      /// getting songs from specific album
      //audioQuery.getSongsFromAlbum(album: album.name);
    } );

  }

  List<String> loadSongs(){
    List<String> songList = [];
    // SD Card Path
    Directory dir = Directory('/storage/emulated/0/');
    List<FileSystemEntity> files =  dir.listSync(recursive: true);
    for(FileSystemEntity currentFile in files){
      String path = currentFile.path;
      if(path.endsWith(".mp3")){
        songList.add(path);
      }
    }
    return songList;
  }

}
