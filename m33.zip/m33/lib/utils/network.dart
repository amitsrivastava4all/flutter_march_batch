

import 'package:connectivity/connectivity.dart';
import 'package:flutter/services.dart';

Future<bool> isConnectedToNetwork() async{
  ConnectivityResult result = ConnectivityResult.none;
  final Connectivity _connectivity = Connectivity();

  try {
    result = await _connectivity.checkConnectivity();
    print(":::::::::::::::: Result is $result");
    if(result == ConnectivityResult.wifi || result == ConnectivityResult.mobile){
        return true;
    }

  } on PlatformException catch (e) {
    print(e.toString());
  }
  return false;
}