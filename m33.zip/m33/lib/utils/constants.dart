class Constants{
  static final String LOGIN_IMG_URL = 'https://www.pnas.org/content/pnas/118/4/e2025750118/F1.large.jpg';
  static final String FB_URL = "assets/fb.png";
  static final String GOOGLE_URL ="assets/google.png";
  static final String SINGER_URL = "https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/singers.json";
  static final String BASE_URL = "https://itunes.apple.com/search";
  static final int LIMIT = 25;
  static String getSongURL(String singerName){
    return BASE_URL+"?term=$singerName&limit=$LIMIT";
  }
}
