import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:musicapp/models/singer.dart';
import 'package:musicapp/models/song.dart';
import 'package:musicapp/respositories/server.dart';
import 'package:musicapp/screens/songs.dart';
import 'package:musicapp/utils/localsongs.dart';
import 'package:musicapp/widgets/customdrawer.dart';
class SingerScreen extends StatefulWidget {
  User user;
  SingerScreen(this.user, {Key key}) : super(key: key);

  @override
  _SingerScreenState createState() => _SingerScreenState();
}

class _SingerScreenState extends State<SingerScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    LocalSong.loadSongs2();
    //Server.getSingers();
  }

  _printSinger( Singer singerInfo){
    Size size = MediaQuery.of(context).size;
    print('SingerInfo $singerInfo');

    return Container(
      child: Column(
        children: [


          Container(
            //margin: EdgeInsets.only(bottom: 150),
            width: size.width/2,
            height: size.height/5,
            child: InkWell(
              onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (ctx)=>Songs(singerInfo.name)));
              },
              highlightColor: Colors.blue,
              splashColor: Colors.deepPurpleAccent,
              child: CircleAvatar(
                backgroundImage: NetworkImage(singerInfo.photo),
              ),
            ),
            decoration: BoxDecoration(

              //image: DecorationImage(image: NetworkImage(singerInfo.photo)),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.amber,width: 5,style: BorderStyle.solid)


            ),

          ),
          Text(singerInfo.name)
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Singers'),
      ),
      drawer: CustomerDrawer(widget.user),
      body: Container(

        child: FutureBuilder(
          future: Server.getSingers(),
          builder: (BuildContext context, AsyncSnapshot<List<Singer>> asyncSnapShot){
            if(asyncSnapShot.hasError){
              return new Text('Error During Fetching Singers');
            }
            if(!asyncSnapShot.hasData){
              return Center(child: CircularProgressIndicator(),);
            }
            return GridView.builder(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2,crossAxisSpacing: 20,mainAxisSpacing: 20),
                itemBuilder: (BuildContext parent, int index){
                  return _printSinger(asyncSnapShot.data[index]);
                },
                itemCount: asyncSnapShot.data.length,
            );
          },

        ),
      ),
    );
  }
}
