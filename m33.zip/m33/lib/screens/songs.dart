import 'package:flutter/material.dart';
import 'package:musicapp/models/song.dart';
import 'package:musicapp/respositories/server.dart';
import 'package:musicapp/screens/player.dart';
import 'package:musicapp/utils/localsongs.dart';
import 'package:musicapp/utils/network.dart';
class Songs extends StatefulWidget {
  String singerName;
   Songs( this.singerName, {Key key}) : super(key: key);

  @override
  _SongsState createState() => _SongsState();
}

class _SongsState extends State<Songs> {

  _printSong(Song song){
    return Card(
      child: ListTile(
        leading: Image.network(song.photo),
        title: Text(song.name),
        subtitle: Text(song.artistName),
        trailing: IconButton(

          icon: Icon(Icons.play_circle_fill,size: 30, ), color: Colors.redAccent
          ,onPressed: (){
            Navigator.of(context).push(MaterialPageRoute(builder: (_)=>Player(song)));
        },),
      ),
    );
  }
  bool isOnline = false;

  checkConnection() async{
    isOnline = await isConnectedToNetwork();
    print("IS Online ::::::: $isOnline");
    setState(() {

    });
    if(isOnline==false){
      // SD CARD
      LocalSong().checkPermission();
    }
  }

  @override
   initState() {
    super.initState();
    checkConnection();


  }

  offline(){

        List<String> songList = LocalSong.songs;
        if(songList.length==0){
          return Container(child: Center(child: Text('No Song Found in SD Card'),));
        }

        return ListView.builder(itemCount: songList.length,
          itemBuilder: (BuildContext parent , int index){
            return Text(songList[index]);
          },
        );

  }

  online(){
    return FutureBuilder(
      future: Server.getSongBySinger(widget.singerName),
      builder: (BuildContext context, AsyncSnapshot<List<Song>> snapShot){
        songs = snapShot.data;
        if(snapShot.hasError){
          return Text('Error in Song Fetching...');
        }
        if(!snapShot.hasData){
          return Center(child: CircularProgressIndicator(),);
        }
        return ListView.builder(itemCount: snapShot.data.length,
          itemBuilder: (BuildContext parent , int index){
            return _printSong(snapShot.data[index]);
          },
        );
      },
    );
  }

  List<Song> songs = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          songs.sort((Song first, Song second)=>first.name.compareTo(second.name));
          setState(() {

          });
        },
        elevation: 4,
        backgroundColor: Colors.deepOrange,
        child: Icon(Icons.sort_outlined, color: Colors.black,),
      ),
      body: SafeArea(
        child: isOnline?online():offline(),
      ),
    );
  }
}
