/*
Get the Values b/w 30  to 60 and do the sum of these elements
*/
void main() {
  List<int> list = [10, 20, 30, 40, 150, 60, 100];
  int result =
      list.getRange(2, 6).toList().fold(0, (sum, element) => sum + element);
  print(result);
}
