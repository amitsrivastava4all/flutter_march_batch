/*
Sort the Names in Descending Order
*/
void main() {
  List<String> names = ["Ram", "Amit", "Shyam", "Ajay", "Sohan"];
  /*print("Amit".compareTo("Ram")); // -1
  print("Ram".compareTo("Amit")); // 1
  print("Amit".compareTo("Amar")); // 1
  print("Amit".compareTo("Amit")); // 0
  */
  //names.sort((first, second) => first.compareTo(second)); // Ascending
  names.sort((first, second) => second.compareTo(first));
  print(names);
  //names.sort((first, second)=>)
}
