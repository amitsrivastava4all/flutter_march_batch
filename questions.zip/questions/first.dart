/*
skip 3 records and then sort the records and print the records
e.g [10,20,30,40,150,60,100]
*/
void main() {
  List<int> list = [10, 20, 30, 40, 150, 60, 100];
  //List<int> skippedList = list.skip(3).toList();
  List<int> skippedList = list.skip(3).toList();
  skippedList.sort((first, second) => first - second);
  skippedList.forEach((element) => print(element));
  //print(skippedList);
}
