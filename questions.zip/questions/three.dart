/*
Check in a List all the Elements must be greater than 5 or not
*/
void main() {
  List<int> list = [10, 20, 30, 40, 150, 60, 100];
  //bool result = list.every((int ele) => ele > 5);
  //print(result);
  print(list.every((int ele) => ele > 5) ? "Yes Every Element is >5" : "No ");
}
