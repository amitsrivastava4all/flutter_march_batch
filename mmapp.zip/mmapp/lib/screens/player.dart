import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:musicapp/models/song.dart';
import 'package:musicapp/utils/wave.dart';
import 'package:musicapp/widgets/playerbutton.dart';
class Player extends StatefulWidget {
  Song song;
   Player(this.song, {Key key}) : super(key: key);

  @override
  _PlayerState createState() => _PlayerState();
}

class _PlayerState extends State<Player> {
  AudioPlayer audioPlayer;
  bool isPlaying = false;
  Duration _duration;
  Duration _position;
  _playSong(){
    setState(() {
      isPlaying = !isPlaying;
      if(isPlaying) {
        _playSongOnPlayer(widget.song.audioURL);
      }
      else{
        _pauseSong();
      }
    });
  }

  _pauseSong() async{
    int response = await audioPlayer.pause();
    if(response == 1){
      setState(() {
        isPlaying = false;
      });
    }
    else{
      isPlaying = true;
      print("Error During Pause ");
    }
    setState(() {

    });
  }

  _playSongOnPlayer(String path) async{
    int response = await audioPlayer.play(path);
    if(response == 1){
      setState(() {
        isPlaying = true;
      });
    }
    else{
      isPlaying = false;
      print("Error During Play ");
    }
    setState(() {

    });
  }


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    audioPlayer = new AudioPlayer();
    audioPlayer.onDurationChanged.listen((event) {
      setState(() {
        _duration = event;
      });
    });
      audioPlayer.onAudioPositionChanged.listen((event) {
        setState(() {
          _position = event;
        });
      });
      audioPlayer.onPlayerCompletion.listen((event) {
        setState(() {
          isPlaying = false;
        });
      });
  }

  String getPositionInSeconds(){
   //  //print("MS $milliSeconds");
   // // print("SPlit ${milliSeconds.toString().split(".").toList()[1].substring(0,2)}");
   //  //return milliSeconds.toString().split(".").toList()[1].substring(0,2);
   //  print(_duration.toString());
    return "${_position.toString().split(".").first} / ${_duration.toString().split(".").first}";
  }

  String getDurationInSeconds(){
    return "${_duration.toString().split(".").first}";
  }




  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      body: SafeArea(
        child: Column(

          children: [
            Container(
              alignment: Alignment.center,

              color: Colors.deepPurpleAccent,
              height: size.height * 0.40,
              width: double.infinity,
              child: Stack(
                children: [
                  Container(
                    height: size.height * 0.30,
                    width: size.height * 0.30,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white, width: 5),
                      shape: BoxShape.circle,
                      image: DecorationImage(
                        fit: BoxFit.fill,
                        image: NetworkImage(widget.song.photo)
                      )
                    ),
                  )
                ],
              ),
            ),
          
          Padding(
            padding: EdgeInsets.all(10),
              child: Text(widget.song.name,style:
              TextStyle(fontSize: 20, fontWeight: FontWeight.bold),)),
            Text(widget.song.artistName,style: TextStyle(fontSize: 20),),
            Row(

              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.center,

              crossAxisAlignment: CrossAxisAlignment.center,
              //verticalDirection: VerticalDirection.down,
              children: [
                PlayerButton(Icons.skip_previous, 40, ()=>{}, color: Colors.blue),
                PlayerButton(!isPlaying?Icons.play_circle_fill_outlined:Icons.pause_circle_filled_sharp, 100, _playSong),
                PlayerButton(Icons.stop, 40, ()=>{}, color: Colors.redAccent,),
                PlayerButton(Icons.skip_next, 40, ()=>{}, color: Colors.blue)


            ],),
            Slider(value: (_position!=null && _duration!=null
                && _position.inMilliseconds>0 &&
                _position.inMilliseconds<_duration.inMilliseconds)
                ?_position.inMilliseconds/ _duration.inMilliseconds:0.0 , onChanged: (val){
                  final currentPosition = val * _duration.inMilliseconds;
                  audioPlayer.seek(Duration(milliseconds: currentPosition.round()));


            }),
            Text((_position!=null && _duration!=null?getPositionInSeconds():_duration!=null?getDurationInSeconds():0.0).toString()),
            AnimatedOpacity(opacity: isPlaying?1.0:0.0, duration: Duration(seconds: 1), child: Wave(size: size,isPlaying: isPlaying,))

          ],
        ),
      ),
    );
  }
}
