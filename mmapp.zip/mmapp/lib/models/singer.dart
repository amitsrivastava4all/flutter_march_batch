class Singer{
  String name;
  String photo;
  Singer(this.name , this.photo);

  @override
  String toString() {
    return 'Singer{name: $name, photo: $photo}';
  }
}
