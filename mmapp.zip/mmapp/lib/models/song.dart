class Song{
  String _name;
  String _photo;
  String _artistName;
  String _audioURL;
  Song(this._name, this._photo, this._artistName, this._audioURL);

  String get audioURL => _audioURL;

  set audioURL(String value) {
    _audioURL = value;
  }

  String get artistName => _artistName;

  set artistName(String value) {
    _artistName = value;
  }

  String get photo => _photo;

  set photo(String value) {
    _photo = value;
  }

  String get name => _name;

  set name(String value) {
    _name = value;
  }
}