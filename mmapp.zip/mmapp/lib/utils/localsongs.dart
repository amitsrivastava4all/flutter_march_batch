
import 'dart:io';

import 'package:musicapp/utils/toast.dart';
import 'package:permission_handler/permission_handler.dart';

class LocalSong{
  static List<String> songs = [];
  LocalSong(){
    checkPermission();
  }
  checkPermission() async{
    if(await Permission.storage.request().isGranted){
      songs = loadSongs();
    }
    else if(await Permission.storage.isPermanentlyDenied){
      showToast('No Permission for SD Card');
    }
  }
  List<String> loadSongs(){
    List<String> songList = [];
    // SD Card Path
    Directory dir = Directory('/storage/emulated/0/');
    List<FileSystemEntity> files =  dir.listSync(recursive: true);
    for(FileSystemEntity currentFile in files){
      String path = currentFile.path;
      if(path.endsWith(".mp3")){
        songList.add(path);
      }
    }
    return songList;
  }

}
