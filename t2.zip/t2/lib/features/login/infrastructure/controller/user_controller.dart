import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:test_engine/features/login/domain/entities/user.dart';
import 'package:test_engine/features/login/infrastructure/models/usermodel.dart';
import 'package:test_engine/features/login/infrastructure/repository/user_repository.dart';

class LoginController extends GetxController{
  UserRepository _userRepository = Get.put(UserRepository());
  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();
  RxString result = "Unable to Register".obs;
  void takeUserInfo(String userid, String password) async{
    UserModel user = new UserModel(userid, password);
    String documentId = await _userRepository.register(user);
    if(documentId.length>0){
        result.value = "Register SuccessFully $documentId";
        //Get.snackbar(result.value, 'Brain Mentors');
    }
    print("result is $result");

  }
  doRegister(){
    String userid = t1.text;
    String password = t2.text;
    takeUserInfo(userid, password);
  }
}