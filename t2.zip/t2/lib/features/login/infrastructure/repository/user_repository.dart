// How to DO


import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:test_engine/features/login/domain/entities/user.dart';
import 'package:test_engine/features/login/domain/interfaces/user_interface.dart';
import 'package:test_engine/features/login/infrastructure/models/usermodel.dart';

/// Call API Client get the response and convert it and give result to presentation
/// CALL FireBase API for CRUD and Doing the Conversion
/// How to do
class UserRepository implements UserInterface{
  final FirebaseFirestore dbReference = FirebaseFirestore.instance;
  @override
  login(UserModel userModel) {

  }

  @override
 Future<String> register(UserModel userModel) async{
    CollectionReference collectionReference = await dbReference.collection('users');
    DocumentReference documentReference = await collectionReference.add(userModel.toJSON()); //Object to Map Conversion
    return documentReference.id;
  }

  @override
  removeUser() {
    // TODO: implement removeUser
    throw UnimplementedError();
  }

  @override
  updatePassword() {
    // TODO: implement updatePassword
    throw UnimplementedError();
  }



}
