import 'package:test_engine/features/login/domain/entities/user.dart';

class UserModel extends User{
  UserModel(String userName, String password) : super(userName, password);
  // Conversion Method
  Map<String, dynamic> toJSON(){
    return {
      "userid":userName,
      "password":password
    };
  }

}