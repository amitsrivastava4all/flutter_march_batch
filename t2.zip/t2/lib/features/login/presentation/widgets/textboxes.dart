import 'package:flutter/material.dart';
class TextBoxes extends StatelessWidget {
  String _txt;
  TextEditingController _t1 ;

   TextBoxes(this._txt, this._t1, {Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: TextField(
        controller: _t1,
        style: TextStyle(fontSize: 20),
        decoration: InputDecoration(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          helperText: 'Type '+this._txt,
          helperStyle: TextStyle(color: Colors.lightGreen),
          labelText: 'Enter '+this._txt,
          prefixIcon: Icon(Icons.person)

        ),
      ),
      
    );
  }
}
