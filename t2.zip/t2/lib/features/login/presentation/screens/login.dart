import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:test_engine/common/config/config.dart';
import 'package:test_engine/features/login/infrastructure/controller/user_controller.dart';
import 'package:test_engine/features/login/presentation/widgets/textboxes.dart';
/// Design
class Login extends StatelessWidget {
  //LoginController _loginController = new LoginController();
  LoginController _loginController = Get.put(LoginController());
  Login({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: SafeArea(
        child: Container(
        child: Stack(
          children: [
            Container(
              child: Image.network(FlavorConfig.loginImage),

            ),
            Obx(()=> Text('${_loginController.result.value}', style: TextStyle(fontSize: 30, color:Colors.green),)),

            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
              TextBoxes('Userid', _loginController.t1),
              TextBoxes('Password', _loginController.t2),
              ElevatedButton(onPressed: (){
                  _loginController.doRegister();
                  Get.snackbar('Done', 'Brain Mentors'
                      ,snackPosition: SnackPosition.BOTTOM,
                      backgroundColor: Colors.redAccent, colorText: Colors.white,icon: Icon(Icons.close,size: 30,));
              },child: Text('Register'),)
            ],)
          ],
        ),
    ),
      ));
  }
}
