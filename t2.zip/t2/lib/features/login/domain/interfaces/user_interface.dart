import 'package:test_engine/features/login/domain/entities/user.dart';
import 'package:test_engine/features/login/infrastructure/models/usermodel.dart';

/// What to Do
/// User Operations - CRUD
class UserInterface{

  register(UserModel userModel){

  }
  login(UserModel userModel){

  }
  updatePassword(){

  }
  removeUser(){

  }

}
