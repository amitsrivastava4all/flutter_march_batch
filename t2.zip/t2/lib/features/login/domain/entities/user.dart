class User{
  String userName;
  String password;
  User(this.userName, this.password);
}