import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:test_engine/features/login/presentation/screens/login.dart';

import 'common/config/config.dart';
void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); //Aug 2020
  FlavorConfig(flavor: Flavor.DEV,
      color: Colors.redAccent,
      values: FlavorValues(baseUrl: "http://10.1.10.90:1234"));
    runApp(
        GetMaterialApp(
        title: FlavorConfig.appName,
        home: Login(),
      )
    );
}