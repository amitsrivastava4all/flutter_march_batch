import 'package:flutter/material.dart';

import 'common/config/config.dart';
void main() {
  FlavorConfig(flavor: Flavor.PRODUCTION,
      color: Colors.blueAccent,
      values: FlavorValues(baseUrl: "http://10.1.10.290:1234"));
  runApp(
      MaterialApp()
  );
}