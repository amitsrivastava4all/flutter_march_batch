import 'package:flutter/material.dart';
import 'package:imagesearchapp/widgets/customappbar.dart';

class SearchImage extends StatefulWidget {
  @override
  _SearchImageState createState() => _SearchImageState();
}

class _SearchImageState extends State<SearchImage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(150), child: CustomAppBar()),
      body: Container(),
    );
  }
}
