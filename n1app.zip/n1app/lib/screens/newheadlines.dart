import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:newsapp/utils/server.dart';

class NewsHeadlines extends StatefulWidget {
  @override
  _NewsHeadlinesState createState() => _NewsHeadlinesState();
}

class _NewsHeadlinesState extends State<NewsHeadlines> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print("Server Call");
    Future<Response> future = Server.getHeadLines();
    future
        .then((response) => print("Res Data ${response.data['articles']}"))
        .catchError((err) => print(err));
  }

  @override
  Widget build(BuildContext context) {
    print("Build Call");
    return Scaffold(
      appBar: AppBar(
        title: Text('HeadLines'),
      ),
      body: Container(),
    );
  }
}
