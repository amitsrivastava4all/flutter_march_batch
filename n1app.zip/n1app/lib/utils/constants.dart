class Constants {
  static final String API_KEY = "11f0dc28d8874be0bb82287cbcf26121";
  static final String NEWS_HEADLINES =
      "https://newsapi.org/v2/top-headlines?country=us&apiKey=$API_KEY";
}
