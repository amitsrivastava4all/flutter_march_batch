import 'package:dio/dio.dart';
import 'package:newsapp/utils/constants.dart';

class Server {
  _Server() {}
  static Future<Response> getHeadLines() {
    Future<Response> future = Dio().get(Constants.NEWS_HEADLINES);
    return future;
  }
}
