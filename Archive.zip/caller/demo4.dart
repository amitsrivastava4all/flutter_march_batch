import '../oops/demo3.dart';

void main() {
  Customer customer = new Customer(1001, "Ram", 53453);
  customer.id = -1001;
  customer.balance = -99999;
  print("Id ${customer.id} Name ${customer.name} Balance ${customer.balance}");
  // customer.id = 1001;
  // customer.name = 'Ram';
  // customer.balance = 9999;
}
