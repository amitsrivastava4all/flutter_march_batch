import 'dart:io';

import './demo1.dart';

// Immutable (Every time change will create a new object in the memory)
class GitFile {
  final String content;
  // Constant Constructor
  const GitFile(this.content);
}

void main() {
  GitFile file = new GitFile("Hi");
  // file.content = 'HELLO'; // Error
  GitFile file = new GitFile("Hello");
  // final vs const
  const int x = 100; // compile time constant
  print("Enter the Id ");
  final int id = int.parse(stdin.readLineSync()); // run time constant
  print("Enter the Name");
  String name = stdin.readLineSync();
  print("Enter the Salary");
  double salary = double.parse(stdin.readLineSync());
  Employee emp = Employee.takeInput(id, name, salary); // run time values
  //Employee emp = Employee.takeInput(1001, 'Ram', 9090); // compile time values
}
