class Human {
  int legs;
  int hands;
  int ears;
  int height;
  int weight;
}

class Employee {
  int id; // Instance Member Variables
  String name; // Instance Member Variables
  double salary; // Instance Member Variables
  String companyName;
  // Default Constructor (No Argument Constructor)
  // Class Name and Constructor name is same
  // Constructor not return anything
  // Constrcutor it used to initalize the member variable of a class
  /*Employee() {
    print("Default Cons Call");
    id = 1001;
    name = 'Ram';
    salary = 9090;
  }*/
  Employee() {
    companyName = "AliBaba";
  }
  // Parameteized Constructor
  // Named Optional Parameter and Default Parameter
  // Employee({int id = 0, String name = '', double salary = 0.0}) {
  //   // this - it is a keyword and it hold the current calling object reference
  //   this.id = id;
  //   this.name = name;
  //   this.salary = salary;
  // }
  // Named Paramerized Constructor
  /*Employee.takeInput(int id, String name, double salary) {
    // Instance Variables Initalize
    // this. id = this.id++;
    this.id = id;
    this.name = name;
    this.salary = salary;
  }*/
  // Short Hand Way of Creating Constructor
  Employee.takeInput(this.id, this.name, this.salary);

  Employee.takeInput2(int id, String name) {
    this.id = id;
    this.name = name;
  }
}

void main() {
  /*Human tim = new Human();
  tim.legs = 2;
  tim.hands = 2;
  tim.weight = 100;
  tim.height = 160;*/
  Employee ram;
  //ram = new Employee(); //R.H.S Creating a new object (Creating a New Instance)
  //ram = new Employee(1001, "Ram", 9999);
  //ram = new Employee(id: 1001);
  ram = Employee.takeInput(1001, "Ram", 9090);
  print(ram);
  print(ram.id);
  print(ram.name);
  print(ram.salary);
  //Employee shyam = new Employee(1002, "Shyam ", 54353);
  //Employee shyam = new Employee(name: 'Shyam');
  Employee shyam = Employee.takeInput(1002, "Shyam", 5454);
  print(ram == shyam);

  print(shyam.id);
  print(shyam.name);
  print(shyam.salary);
}
