import './demo3.dart';

void main() {
  Customer customer = new Customer(1010, 'Ram', 43242);
  customer.id = -1001; // call setter

  print("Id ${customer.id} Name ${customer.name} Balance ${customer.balance}");
  //customer.id // call getter
  //customer._id = 1434;
}
