class Customer {
  // default all members are public
  int _id; // private (Scope Library/ Dart Application)
  String _name;
  double _balance;
  //Customer(this.id, this.name, this.balance);
  Customer(int id, String name, double balance) {
    if (id < 0) {
      print("Invalid Id ");
      return;
    }
    if (balance < 0) {
      print("Invalid Balance ");
      return;
    }
    this._id = id;
    this._name = name;
    this._balance = balance;
  }

  set id(int id) {
    if (id < 0) {
      throw new Exception('INvalid ID');
    }
    this._id = id;
  }

  get id => _id;

  set name(String name) => this._name = name;
  get name => _name;

  set balance(double balance) => this._balance = balance;

  get balance => this._balance;
}
