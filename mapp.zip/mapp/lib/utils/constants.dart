class Constants{
  static final String LOGIN_IMG_URL = 'https://www.pnas.org/content/pnas/118/4/e2025750118/F1.large.jpg';
  static final String FB_URL = "assets/fb.png";
  static final String GOOGLE_URL ="assets/google.png";
}
